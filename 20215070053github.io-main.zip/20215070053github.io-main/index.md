#  Merhaba  ben  Sena  GÜRKAN
##  Yönetim  Bilişim  Sistemeleri
###  Github  sayfasıdır
bu sayfa içerisinde
*  Kişisel projeler
*  çalışmalar 
* sunumlar

paylaşılmaktadır

Sayfa yöneticisi [Sena GÜRKAN ](https://www.linked.com/in/sena-gürkan-208a67223)


